<?php

#[\AllowDynamicProperties]
class Product
{

    public ?string $title = 'Some product';
    public int|float $price;

}